import React, { useState, useEffect } from 'react';
import { NavTab, UserProfile, CalendarEvent, NoteItem, ShoppingItem, ChatMessage, PhotoMedia, VaultItem, PartnerLocation, FavoritePlace, CycleLog, TimelineMilestone, WishlistItem, CoupleGoal, RestaurantItem, MovieItem, AffectionGIF } from './types';
import { StorageService } from './lib/storage';
import { playAffectionSound } from './lib/audio';
import { subscribeCollection, saveDocument, removeDocument, seedCollectionIfEmpty } from './lib/firebase';
import { HeaderNavbar } from './components/HeaderNavbar';
import { NavigationTabs } from './components/NavigationTabs';
import { SendAffectionModal } from './components/SendAffectionModal';
import { DashboardView } from './components/DashboardView';
import { AgendaView } from './components/AgendaView';
import { NotesView } from './components/NotesView';
import { ShoppingListView } from './components/ShoppingListView';
import { ChatView } from './components/ChatView';
import { MediaVaultView } from './components/MediaVaultView';
import { EncryptedVaultView } from './components/EncryptedVaultView';
import { LocationMapView } from './components/LocationMapView';
import { CycleTrackerView } from './components/CycleTrackerView';
import { AnniversaryTimelineView } from './components/AnniversaryTimelineView';
import { WishlistGoalsView } from './components/WishlistGoalsView';
import { DateNightView } from './components/DateNightView';
import { AIAssistantView } from './components/AIAssistantView';
import { SettingsView } from './components/SettingsView';

export function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile>('Fer');
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [isAffectionModalOpen, setIsAffectionModalOpen] = useState(false);
  const [unreadAffectionCount, setUnreadAffectionCount] = useState(0);

  // App State collections initialized from StorageService
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [notes, setNotes] = useState<NoteItem[]>([]);
  const [shoppingItems, setShoppingItems] = useState<ShoppingItem[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [photos, setPhotos] = useState<PhotoMedia[]>([]);
  const [vaultItems, setVaultItems] = useState<VaultItem[]>([]);
  const [partnerLocation, setPartnerLocation] = useState<PartnerLocation>(StorageService.getPartnerLocation());
  const [places, setPlaces] = useState<FavoritePlace[]>([]);
  const [cycleLog, setCycleLog] = useState<CycleLog>(StorageService.getCycleLog());
  const [timeline, setTimeline] = useState<TimelineMilestone[]>([]);
  const [wishlist, setWishlist] = useState<WishlistItem[]>([]);
  const [goals, setGoals] = useState<CoupleGoal[]>([]);
  const [restaurants, setRestaurants] = useState<RestaurantItem[]>([]);
  const [movies, setMovies] = useState<MovieItem[]>([]);
  const [gifs, setGifs] = useState<AffectionGIF[]>([]);
  const [vaultPIN, setVaultPIN] = useState(StorageService.getVaultPIN());

  // Initial Load & Real-Time Online Firestore Synchronization
  useEffect(() => {
    // 1. Seed initial data if collections are empty
    seedCollectionIfEmpty('events', StorageService.getEvents());
    seedCollectionIfEmpty('notes', StorageService.getNotes());
    seedCollectionIfEmpty('shopping', StorageService.getShoppingItems());
    seedCollectionIfEmpty('chat', StorageService.getChatMessages());
    seedCollectionIfEmpty('timeline', StorageService.getTimeline());
    seedCollectionIfEmpty('wishlist', StorageService.getWishlist());
    seedCollectionIfEmpty('goals', StorageService.getGoals());
    seedCollectionIfEmpty('restaurants', StorageService.getRestaurants());
    seedCollectionIfEmpty('movies', StorageService.getMovies());
    seedCollectionIfEmpty('gifs', StorageService.getGIFs());

    // 2. Real-time Listeners across all devices/sessions
    const unsubEvents = subscribeCollection<CalendarEvent>('events', (data) => {
      if (data.length > 0) setEvents(data);
    });
    const unsubNotes = subscribeCollection<NoteItem>('notes', (data) => {
      if (data.length > 0) setNotes(data);
    });
    const unsubShopping = subscribeCollection<ShoppingItem>('shopping', (data) => {
      if (data.length > 0) setShoppingItems(data);
    });
    const unsubChat = subscribeCollection<ChatMessage>('chat', (data) => {
      if (data.length > 0) {
        // Sort chronologically
        const sorted = [...data].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        setChatMessages(sorted);
      }
    });
    const unsubPhotos = subscribeCollection<PhotoMedia>('photos', (data) => {
      if (data.length > 0) setPhotos(data);
    });
    const unsubVault = subscribeCollection<VaultItem>('vault', (data) => {
      if (data.length > 0) setVaultItems(data);
    });
    const unsubPlaces = subscribeCollection<FavoritePlace>('places', (data) => {
      if (data.length > 0) setPlaces(data);
    });
    const unsubTimeline = subscribeCollection<TimelineMilestone>('timeline', (data) => {
      if (data.length > 0) setTimeline(data);
    });
    const unsubWishlist = subscribeCollection<WishlistItem>('wishlist', (data) => {
      if (data.length > 0) setWishlist(data);
    });
    const unsubGoals = subscribeCollection<CoupleGoal>('goals', (data) => {
      if (data.length > 0) setGoals(data);
    });
    const unsubRestaurants = subscribeCollection<RestaurantItem>('restaurants', (data) => {
      if (data.length > 0) setRestaurants(data);
    });
    const unsubMovies = subscribeCollection<MovieItem>('movies', (data) => {
      if (data.length > 0) setMovies(data);
    });
    const unsubGifs = subscribeCollection<AffectionGIF>('gifs', (data) => {
      if (data.length > 0) setGifs(data);
    });

    return () => {
      unsubEvents();
      unsubNotes();
      unsubShopping();
      unsubChat();
      unsubPhotos();
      unsubVault();
      unsubPlaces();
      unsubTimeline();
      unsubWishlist();
      unsubGoals();
      unsubRestaurants();
      unsubMovies();
      unsubGifs();
    };
  }, []);

  // Sync back to StorageService local cache
  useEffect(() => {
    if (events.length > 0) StorageService.saveEvents(events);
  }, [events]);

  useEffect(() => {
    if (notes.length > 0) StorageService.saveNotes(notes);
  }, [notes]);

  useEffect(() => {
    if (shoppingItems.length > 0) StorageService.saveShoppingItems(shoppingItems);
  }, [shoppingItems]);

  useEffect(() => {
    if (chatMessages.length > 0) StorageService.saveChatMessages(chatMessages);
  }, [chatMessages]);

  useEffect(() => {
    if (photos.length > 0) StorageService.savePhotos(photos);
  }, [photos]);

  useEffect(() => {
    if (vaultItems.length > 0) StorageService.saveVaultItems(vaultItems);
  }, [vaultItems]);

  useEffect(() => {
    if (places.length > 0) StorageService.saveFavoritePlaces(places);
  }, [places]);

  useEffect(() => {
    if (timeline.length > 0) StorageService.saveTimeline(timeline);
  }, [timeline]);

  useEffect(() => {
    if (wishlist.length > 0) StorageService.saveWishlist(wishlist);
  }, [wishlist]);

  useEffect(() => {
    if (goals.length > 0) StorageService.saveGoals(goals);
  }, [goals]);

  useEffect(() => {
    if (restaurants.length > 0) StorageService.saveRestaurants(restaurants);
  }, [restaurants]);

  useEffect(() => {
    if (movies.length > 0) StorageService.saveMovies(movies);
  }, [movies]);

  // Handlers with Online Firestore Persistence
  const handleSendAffection = (gifTitle: string, gifUrl: string, message?: string) => {
    playAffectionSound();
    setUnreadAffectionCount((prev) => prev + 1);

    const newChatMsg: ChatMessage = {
      id: `chat-${Date.now()}`,
      sender: currentUser,
      text: `${currentUser} te envió un Cariño: "${gifTitle}" ${message ? `— "${message}"` : ''} 💕`,
      timestamp: new Date().toISOString(),
    };

    setChatMessages((prev) => [...prev, newChatMsg]);
    saveDocument('chat', newChatMsg.id, newChatMsg);
  };

  const handleSyncGoogleCalendar = () => {
    alert('Sincronización con Google Calendar realizada correctamente para sofiferfiguemorin@gmail.com ✓');
  };

  const handleClearData = () => {
    if (confirm('¿Estás seguro de restablecer los datos de la aplicación a su estado de fábrica?')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  return (
    <div className="min-h-screen bg-[#080808] text-[#E0E0E0] font-sans selection:bg-[#C5A059] selection:text-black flex flex-col">
      {/* Header */}
      <HeaderNavbar
        currentUser={currentUser}
        onSelectUser={setCurrentUser}
        unreadAffectionCount={unreadAffectionCount}
        onOpenAffectionModal={() => setIsAffectionModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentTab === 'dashboard' && (
          <DashboardView
            currentUser={currentUser}
            events={events}
            notes={notes}
            shoppingItems={shoppingItems}
            cycleLog={cycleLog}
            partnerLocation={partnerLocation}
            onNavigate={(tab) => setCurrentTab(tab as NavTab)}
            onOpenAffectionModal={() => setIsAffectionModalOpen(true)}
          />
        )}

        {currentTab === 'agenda' && (
          <AgendaView
            currentUser={currentUser}
            events={events}
            onAddEvent={(ev) => {
              setEvents([ev, ...events]);
              saveDocument('events', ev.id, ev);
            }}
            onDeleteEvent={(id) => {
              setEvents(events.filter((e) => e.id !== id));
              removeDocument('events', id);
            }}
            onSyncGoogleCalendar={handleSyncGoogleCalendar}
          />
        )}

        {currentTab === 'notes' && (
          <NotesView
            currentUser={currentUser}
            notes={notes}
            onAddNote={(n) => {
              setNotes([n, ...notes]);
              saveDocument('notes', n.id, n);
            }}
            onTogglePin={(id) => {
              const updated = notes.map((n) => (n.id === id ? { ...n, pinned: !n.pinned } : n));
              setNotes(updated);
              const item = updated.find((n) => n.id === id);
              if (item) saveDocument('notes', id, item);
            }}
            onDeleteNote={(id) => {
              setNotes(notes.filter((n) => n.id !== id));
              removeDocument('notes', id);
            }}
          />
        )}

        {currentTab === 'shopping' && (
          <ShoppingListView
            currentUser={currentUser}
            items={shoppingItems}
            onAddItem={(item) => {
              setShoppingItems([item, ...shoppingItems]);
              saveDocument('shopping', item.id, item);
            }}
            onToggleItem={(id) => {
              const updated = shoppingItems.map((i) => (i.id === id ? { ...i, completed: !i.completed } : i));
              setShoppingItems(updated);
              const item = updated.find((i) => i.id === id);
              if (item) saveDocument('shopping', id, item);
            }}
            onDeleteItem={(id) => {
              setShoppingItems(shoppingItems.filter((i) => i.id !== id));
              removeDocument('shopping', id);
            }}
            onClearCompleted={() => {
              const completed = shoppingItems.filter((i) => i.completed);
              setShoppingItems(shoppingItems.filter((i) => !i.completed));
              completed.forEach((i) => removeDocument('shopping', i.id));
            }}
          />
        )}

        {currentTab === 'chat' && (
          <ChatView
            currentUser={currentUser}
            messages={chatMessages}
            onSendMessage={(msg) => {
              setChatMessages([...chatMessages, msg]);
              saveDocument('chat', msg.id, msg);
            }}
            onOpenAffectionModal={() => setIsAffectionModalOpen(true)}
          />
        )}

        {currentTab === 'photos' && (
          <MediaVaultView
            currentUser={currentUser}
            photos={photos}
            onAddPhoto={(p) => {
              setPhotos([p, ...photos]);
              saveDocument('photos', p.id, p);
            }}
            onToggleFavorite={(id) => {
              const updated = photos.map((p) => (p.id === id ? { ...p, favorite: !p.favorite } : p));
              setPhotos(updated);
              const item = updated.find((p) => p.id === id);
              if (item) saveDocument('photos', id, item);
            }}
          />
        )}

        {currentTab === 'vault' && (
          <EncryptedVaultView
            vaultItems={vaultItems}
            vaultPIN={vaultPIN}
            onAddVaultItem={(vi) => {
              setVaultItems([vi, ...vaultItems]);
              saveDocument('vault', vi.id, vi);
            }}
            onDeleteVaultItem={(id) => {
              setVaultItems(vaultItems.filter((v) => v.id !== id));
              removeDocument('vault', id);
            }}
            onChangePIN={(newPIN) => {
              setVaultPIN(newPIN);
              StorageService.saveVaultPIN(newPIN);
            }}
          />
        )}

        {currentTab === 'location' && (
          <LocationMapView
            currentUser={currentUser}
            partnerLocation={partnerLocation}
            places={places}
            onAddPlace={(pl) => {
              setPlaces([pl, ...places]);
              saveDocument('places', pl.id, pl);
            }}
          />
        )}

        {currentTab === 'cycle' && (
          <CycleTrackerView
            currentUser={currentUser}
            cycleData={cycleLog}
            onUpdateCycle={(updated) => {
              setCycleLog(updated);
              StorageService.saveCycleLog(updated);
              saveDocument('cycle', 'main', updated);
            }}
          />
        )}

        {currentTab === 'timeline' && (
          <AnniversaryTimelineView
            currentUser={currentUser}
            timeline={timeline}
            onAddMilestone={(m) => {
              setTimeline([m, ...timeline]);
              saveDocument('timeline', m.id, m);
            }}
          />
        )}

        {currentTab === 'wishlist' && (
          <WishlistGoalsView
            currentUser={currentUser}
            wishlist={wishlist}
            goals={goals}
            onAddWishlistItem={(w) => {
              setWishlist([w, ...wishlist]);
              saveDocument('wishlist', w.id, w);
            }}
            onToggleWishlistItem={(id) => {
              const updated = wishlist.map((w) => (w.id === id ? { ...w, completed: !w.completed } : w));
              setWishlist(updated);
              const item = updated.find((w) => w.id === id);
              if (item) saveDocument('wishlist', id, item);
            }}
            onAddGoal={(g) => {
              setGoals([g, ...goals]);
              saveDocument('goals', g.id, g);
            }}
            onUpdateGoalProgress={(id, amount) => {
              const updated = goals.map((g) => (g.id === id ? { ...g, currentAmount: g.currentAmount + amount } : g));
              setGoals(updated);
              const item = updated.find((g) => g.id === id);
              if (item) saveDocument('goals', id, item);
            }}
          />
        )}

        {currentTab === 'restaurants' && (
          <DateNightView
            currentUser={currentUser}
            restaurants={restaurants}
            movies={movies}
            onAddRestaurant={(r) => {
              setRestaurants([r, ...restaurants]);
              saveDocument('restaurants', r.id, r);
            }}
            onToggleRestaurantVisited={(id) => {
              const updated = restaurants.map((r) => (r.id === id ? { ...r, visited: !r.visited } : r));
              setRestaurants(updated);
              const item = updated.find((r) => r.id === id);
              if (item) saveDocument('restaurants', id, item);
            }}
            onAddMovie={(m) => {
              setMovies([m, ...movies]);
              saveDocument('movies', m.id, m);
            }}
            onToggleMovieStatus={(id) => {
              const updated = movies.map((m) =>
                m.id === id ? { ...m, status: m.status === 'Vista' ? 'Por ver' : 'Vista' } : m
              );
              setMovies(updated);
              const item = updated.find((m) => m.id === id);
              if (item) saveDocument('movies', id, item);
            }}
          />
        )}

        {currentTab === 'ai_assistant' && (
          <AIAssistantView
            currentUser={currentUser}
            coupleContext={{
              eventsCount: events.length,
              shoppingCount: shoppingItems.length,
              cyclePhase: cycleLog,
              anniversaryDate: '2015-11-08',
            }}
          />
        )}

        {currentTab === 'settings' && (
          <SettingsView
            currentUser={currentUser}
            vaultPIN={vaultPIN}
            onChangePIN={(newPIN) => {
              setVaultPIN(newPIN);
              StorageService.saveVaultPIN(newPIN);
            }}
            onClearData={handleClearData}
          />
        )}
      </main>

      {/* Navigation Tabs (Sticky Bottom for Mobile & Tabs Header for Desktop) */}
      <NavigationTabs activeTab={currentTab} onTabChange={setCurrentTab} />

      {/* Send Affection Interaction Modal */}
      <SendAffectionModal
        isOpen={isAffectionModalOpen}
        onClose={() => setIsAffectionModalOpen(false)}
        currentUser={currentUser}
        gifPresets={gifs}
        onAddCustomGIF={(newG) => {
          const updated = [newG, ...gifs];
          setGifs(updated);
          StorageService.setGIFs(updated);
          saveDocument('gifs', newG.id, newG);
        }}
        onSendAffection={handleSendAffection}
      />
    </div>
  );
}

export default App;
