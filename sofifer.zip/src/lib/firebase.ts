import { initializeApp, getApps } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  onSnapshot,
  setDoc,
  addDoc,
  deleteDoc,
  updateDoc,
  query,
  orderBy,
  getDocs,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

// Use custom Firestore database ID if provided in config
export const db =
  firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== '(default)'
    ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
    : getFirestore(app);

// Generic real-time collection subscription helper
export function subscribeCollection<T>(
  collectionName: string,
  onData: (items: T[]) => void,
  sortField?: string
) {
  try {
    const colRef = collection(db, collectionName);
    const q = sortField ? query(colRef, orderBy(sortField, 'desc')) : colRef;

    return onSnapshot(
      q,
      (snapshot) => {
        const items: T[] = [];
        snapshot.forEach((docSnap) => {
          items.push({ id: docSnap.id, ...docSnap.data() } as T);
        });
        onData(items);
      },
      (error) => {
        console.warn(`Firestore subscription warning on ${collectionName}:`, error);
      }
    );
  } catch (err) {
    console.error(`Failed to subscribe to ${collectionName}:`, err);
    return () => {};
  }
}

// Single document real-time subscription helper
export function subscribeDocument<T>(
  collectionName: string,
  docId: string,
  onData: (data: T | null) => void
) {
  try {
    const docRef = doc(db, collectionName, docId);
    return onSnapshot(
      docRef,
      (docSnap) => {
        if (docSnap.exists()) {
          onData({ id: docSnap.id, ...docSnap.data() } as T);
        } else {
          onData(null);
        }
      },
      (error) => {
        console.warn(`Firestore doc subscription error on ${collectionName}/${docId}:`, error);
      }
    );
  } catch (err) {
    console.error(`Failed to subscribe to doc ${collectionName}/${docId}:`, err);
    return () => {};
  }
}

// Firestore CRUD helper functions
export async function saveDocument(collectionName: string, id: string, data: any) {
  try {
    const docRef = doc(db, collectionName, id);
    await setDoc(docRef, data, { merge: true });
  } catch (err) {
    console.error(`Error saving doc to ${collectionName}/${id}:`, err);
  }
}

export async function addDocument(collectionName: string, data: any) {
  try {
    const colRef = collection(db, collectionName);
    const docRef = data.id ? doc(colRef, data.id) : doc(colRef);
    await setDoc(docRef, data, { merge: true });
    return docRef.id;
  } catch (err) {
    console.error(`Error adding doc to ${collectionName}:`, err);
    return null;
  }
}

export async function removeDocument(collectionName: string, id: string) {
  try {
    const docRef = doc(db, collectionName, id);
    await deleteDoc(docRef);
  } catch (err) {
    console.error(`Error removing doc ${collectionName}/${id}:`, err);
  }
}

export async function updateDocumentFields(collectionName: string, id: string, fields: any) {
  try {
    const docRef = doc(db, collectionName, id);
    await updateDoc(docRef, fields);
  } catch (err) {
    console.error(`Error updating doc ${collectionName}/${id}:`, err);
  }
}

// Seed initial data to Firestore if collection is empty
export async function seedCollectionIfEmpty(collectionName: string, initialData: any[]) {
  try {
    const colRef = collection(db, collectionName);
    const snapshot = await getDocs(colRef);
    if (snapshot.empty && initialData.length > 0) {
      for (const item of initialData) {
        const itemDoc = item.id ? doc(colRef, item.id) : doc(colRef);
        await setDoc(itemDoc, item);
      }
    }
  } catch (err) {
    console.warn(`Could not seed ${collectionName}:`, err);
  }
}
